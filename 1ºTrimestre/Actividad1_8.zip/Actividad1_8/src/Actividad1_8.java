import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.lang.ProcessBuilder.Redirect;

public class Actividad1_8 {

	public static void main(String[] args) throws IOException {
		File directorio = new File(".\\bin");
		System.out.println("Empezamos el proceso...");
		ProcessBuilder pb=new ProcessBuilder("java","Ejemplo5");
		pb.directory(directorio);
		System.out.printf("Directorio de trabajo: %s\n",pb.directory());
		File out=new File("Salida.txt");
		File err=new File("Error.txt");
		File bat=new File("fichero-entrada.txt");
		FileWriter fw=new FileWriter(out);
		try {
			pb.redirectError(Redirect.to(err));
			pb.redirectInput(Redirect.from(bat));
			Process p=pb.start();
			InputStream is=p.getInputStream();
			int c;

			while((c=is.read())!=-1) {
				fw.write((char)c);
				System.out.print((char)c);
			}
			fw.close();
			is.close();
			System.out.println("Fin del proceso");
			System.out.println("Resultado de la ejecucion= "+p.waitFor());
		}
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}
