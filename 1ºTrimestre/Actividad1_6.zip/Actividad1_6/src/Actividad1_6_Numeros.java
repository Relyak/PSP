import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Actividad1_6_Numeros {
	private static boolean isNumeric(String cadena,String cadena2){
		try {
			Integer.parseInt(cadena);
			Integer.parseInt(cadena2);
			return true;
		} catch (NumberFormatException nfe){
			return false;
		}
	}
	public static void main(String[] args) throws IOException {
		InputStreamReader in = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader (in);
		String cadena = null;
		String cadena2 = null;
		int cadenatotal;
		try{
			
			do{
				cadena=br.readLine();
				cadena2=br.readLine();
			}
			while(isNumeric(cadena,cadena2)==false);
			cadenatotal = Integer.parseInt(cadena)+Integer.parseInt(cadena2);
			System.out.println("La suma es "+cadenatotal);
			in.close();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}

}
