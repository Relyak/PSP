import java.io.File;
import java.io.IOException;
import java.io.InputStream; 
import java.io.OutputStream;
import java.util.Scanner;

public class Clase {

	public static void main(String[] args) throws IOException {
		File directorio = new File(".\\bin");
		ProcessBuilder pb = new ProcessBuilder("java", "Actividad1_6_Numeros");
		pb.directory(directorio);
		String texto=""+"\n";
		Scanner sc=new Scanner(System.in);
		int num1;
		int num2;
		// se ejecuta el proceso
		Process p = pb.start();
		// escritura - se envia la entrada
		OutputStream os = p.getOutputStream();
		num1=sc.nextInt();
		num2=sc.nextInt();
		os.write((num1+texto).getBytes());
		os.flush();
		os.write((num2+texto).getBytes());
		os.flush(); // vacia el buffer de salida

		InputStream is = p.getInputStream();
		int c;
		while ((c= is.read())!=-1)
			System.out.print((char) c);
		is.close();
		// COMPROBACION DE ERROR - 0 bien - 1 mal
		int exitVal;
		try{
			exitVal = p.waitFor();
			System.out.println("Valor de Salida: " + exitVal);
		} catch (InterruptedException e) {
			e.printStackTrace(); 
		}
	}


}
