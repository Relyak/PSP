import java.io.IOException;

public class LeerNombre {

	public static void main(String[] args) throws IOException {
		if(args.length!=0) {
			for (int i = 0; i < args.length; i++) {
				System.out.println(args[i]);
			}
			System.exit(1);
		}
		else {
			System.exit(-1);
		}
	}
}
