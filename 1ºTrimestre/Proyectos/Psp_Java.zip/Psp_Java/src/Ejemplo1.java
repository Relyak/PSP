
public class Ejemplo1 {
		public static void main(String[] args) throws Exception {
			Process pb = new ProcessBuilder("NOTEPAD").start();
		}
}