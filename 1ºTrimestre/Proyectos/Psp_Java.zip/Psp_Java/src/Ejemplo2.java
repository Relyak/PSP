import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class Ejemplo2 {
	public static void main(String[] args) throws IOException {
		//Ejecutamos el proceso DIR
		Process p = new ProcessBuilder("CMD", "/C", "DIRR").start();
		//Mostramos catheter a catheter la salida generada por DIR
		int exitVal;
		try{
			InputStream is = p.getInputStream();
			int c;
			while((c = is.read())!=-1) 
				System.out.print((char) c);
			is.close();
		} catch(Exception e) {
			e.printStackTrace();
		}

		try {
			exitVal = p.waitFor(); //recoge la salida de System.exit()
			System.out.println("Valor de Salida: " + exitVal);
		}
		catch (InterruptedException e) {
			e.printStackTrace();

		}
		try {
			InputStream er = p.getErrorStream();
			BufferedReader brer =new BufferedReader(new InputStreamReader(er));
			String liner = null;
			while((liner = brer.readLine()) != null)
				System.out.println("ERROR>" + liner);
		}catch (IOException ioe){
			ioe.printStackTrace();
		}


	}
}
