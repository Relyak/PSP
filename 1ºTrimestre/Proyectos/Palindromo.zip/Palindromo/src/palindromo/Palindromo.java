/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package palindromo;

import java.util.Scanner;

/**
 *
 * @author david
 */
public class Palindromo {

    public static boolean esPalindromo(String s) {
        int N = s.length();
        for (int i = 0; i < N / 2; i++) {
            if (s.charAt(i) != s.charAt(N - 1 - i)) {
                return false;
            }
        }
        return true;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Inserte palabra: ");
        String cadena = sc.nextLine();
        boolean valor = esPalindromo(cadena);
        if (cadena.equals("")) {
            System.out.println("La cadena esta vacia");
        } else {
            if (valor == true) {
                System.out.println("si es un palindromo");
            } else {
                System.out.println("no es un palindromo");
            }
        }
    }

}
